---
name: "quiz-debrief"
description: "Use when the user uploads a graded quiz (screenshots/PDF) for a course: analyze it, update that course's Quiz Patterns note, and refresh the chapter notes' quiz simulations."
---

# Quiz Debrief

Turns each graded quiz into a sharper model of how that professor writes quizzes, stored in the user's notes vault so it builds up across sessions.

## Where things live
- Vault: the user's Obsidian vault (e.g. `Atlas`), course folder `Courses/<semester>/<COURSE>/`.
- Pattern profile: `<COURSE> Quiz Patterns.md` in that course folder (frontmatter `type: quiz-patterns`, tags `course/<code>`). Create it if it doesn't exist, using the structure below.
- Chapter notes: `Chapter N Summary - <Title>.md` (made by the course-summary skill), each ending in a `## Quiz Simulation` section.
- Always work on the device copy through the device bridge; check the file hasn't changed since you last wrote it before overwriting.

## Steps
1. **Transcribe the quiz.** For every question record: number, format (MC / T-F / fill-in / other), points, the question (short), the options, the user's answer, the correct answer, and the grade shown. If the user says the grader was wrong on a question (e.g. marked Incorrect but actually correct), record it as correct and note the grader glitch.
2. **Trace each question to its source.** Search the textbook text, the lecture slides, and any tutorial or handout in the course folder or claude.ai Project for the sentence it came from. Note the page or section. Say explicitly whether it's word-for-word, paraphrased, or applied/computed.
3. **Update the pattern profile.** In `<COURSE> Quiz Patterns.md`:
   - Add a `### Quiz N` block to the Quiz log (table: #, format, question, answer, source, result) plus a one-line **Lesson** for every lost point.
   - Revise the **Current profile** table: question count, point scheme, format mix, source mix (book vs slides vs tutorial), how questions are built from the source (verbatim sentence, swapped term, contrast, calculation), typical traps, time taken. Raise or lower each row's confidence based on how many quizzes support it. Remove patterns that later quizzes contradict.
   - Keep the **How to study for this professor** checklist in step with the profile.
4. **Refresh the simulations.** For each chapter note in scope for the *next* quiz, rewrite its `## Quiz Simulation` section so it matches the current profile exactly: same question count, same point scheme, same format mix, same source mix, same question-building style. Put answers in folded callouts (`> [!success]- Answer`) with the page or section cited. Add a warning callout to the relevant chapter section for any concept the user lost points on. If the upcoming quiz is cumulative, add or refresh a `## Cumulative Review` block covering earlier material that past quizzes drew from (e.g. software tutorials) and that hasn't been tested yet.
5. **Verify.** Every simulated answer must be checkable against the cited source sentence. Never invent a fact the sources don't state.
6. **Report** in 3–5 lines: the score, what changed in the profile, and which notes were updated.

## Pattern profile skeleton
```
# <COURSE> Quiz Patterns — <Professor>
## Current profile (after K quizzes)
| Pattern | Evidence | Confidence |
## How to study for this professor
## Quiz log
### Quiz 1: <topics> (score x/y)
| # | Format | Question | Answer | Source | Result |
**Lesson:** ...
```