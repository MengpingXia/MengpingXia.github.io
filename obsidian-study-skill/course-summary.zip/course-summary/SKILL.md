---
name: "course-summary"
description: "Use when the user wants a chapter's textbook + lecture slides (+ their existing course notes) turned into a single consistent-format markdown study note, e.g. for an Obsidian vault."
---

# Course Chapter Summary Note

Produces one polished markdown study note per chapter, built from primary course materials, in a fixed format that stays identical across courses and chapters so a vault of these notes reads as one system.

## When to use

The user names a course chapter and points at source materials — a textbook (PDF/ebook), a lecture slide deck (PDF/PPTX) for that chapter, and optionally an existing notes vault (Obsidian or similar) — and asks for a summary note, study note, or chapter notes to be created/saved into that vault.

## Inputs to locate first

1. **The chapter's textbook content.** If the textbook is one large PDF, do not read it in full: find the chapter's page range first (search the table of contents or a heading like "CHAPTER N" / "N <Chapter Title>", then find the next chapter's heading as the upper bound), and extract only that range. Prefer `pdftotext -layout` (or equivalent) over paging through page-by-page with a PDF viewer — it's far cheaper in tokens and preserves tables/structure well enough to read.
2. **The chapter's slide deck.** Usually much shorter (tens to ~100 pages) — extract it in full with the same method. Slides often contain the *instructor's own worked examples* (different numbers/company names than the textbook) and in-class practice questions with multiple-choice answers — both are valuable and the textbook alone won't have them.
3. **Existing notes for this course**, if a vault/folder is connected. Read the notes already taken for this and adjacent chapters before writing anything. This tells you: the user's own shorthand/numbering conventions, filenames already in use (so you don't collide with or duplicate an existing raw lecture-notes file), and terminology already established. Do not just replicate the shorthand notes — produce a fuller, structured reference note that complements them, and link to them. If the user's notes contain a misconception, flag it with a `> [!warning]` in the relevant section.
4. **The course's quiz-pattern profile**, if one exists: `<COURSE> Quiz Patterns.md` in the course folder (maintained by the quiz-debrief skill). It describes how this professor builds quizzes — question count, point scheme, format mix, which sources questions are lifted from, and typical traps. Use it for part 11 below.
5. **Any other supplementary material** in the same course folder or the attached claude.ai Project (extra summaries, practice sheets, software tutorials, spreadsheets) — skim for anything that adds worked numbers or context, but the textbook + slides + existing notes are the primary sources of truth; don't invent numbers that aren't in the sources.

## Fixed output structure

Always use this skeleton, in this order, so every chapter note across every course looks the same:

1. **Title** — `# Chapter N Summary — <Chapter Title>`
2. *Italic source line* — which textbook edition/chapter and which slide deck were used.
3. *Italic related-notes line* — Obsidian-style `[[wikilinks]]` to the existing raw lecture note(s) for this chapter and adjacent chapters, if any exist in the vault.
4. **Learning Objectives** — bullet list, taken verbatim from the textbook/slides if stated (LO1, LO2, ...).
5. A short **`> [!tip]` callout** giving the one-paragraph "big picture" thread that ties the chapter together — write this yourself, don't copy a random sentence.
6. **One H2 section per textbook subsection** (2.1, 2.2, 2.3, ... using the textbook's own numbering/titles as headers), each containing:
   - The core definition/equation as a fenced code block or bold inline formula.
   - Sub-points as concise bullets — compress the textbook's prose, don't paraphrase it paragraph-by-paragraph.
   - Every worked example that appears in either the textbook or the slides, as a `> [!example]` callout with the full numbers shown (source data → each intermediate calculation → the final answer). Keep textbook examples and slide examples both — they usually differ (different companies/scenarios) and having both gives more practice surface.
   - Use `> [!warning]` for a genuinely confusable point (e.g., two competing definitions of the same term), and for any concept the quiz-pattern profile shows the user has lost points on.
7. **Quick Formula Sheet** — one table, every formula from the chapter, concept → formula, near the end for fast pre-exam scanning.
8. **Key Terms** — one table, term → one-line definition, glossary-style.
9. **Practice Questions — with answers** — pull every in-class/slide practice question (including multiple-choice options), each followed by `→ **answer**` plus a one-line justification computed from the chapter's own formulas. Verify every numeric answer by recomputing it yourself before writing it down — don't trust a slide's revealed answer without checking the arithmetic.
10. **Common Pitfalls / Things to Double-Check** — 4-6 bullets on the mistakes the chapter's material invites (sign errors, which items are cash vs noncash, which rate to use when, etc.).
11. **Quiz Simulation** — only if a quiz-pattern profile exists (or the user asks). A mock quiz that mirrors the profile exactly: same question count, point scheme, format mix and question-building style (e.g. near-verbatim definition sentences turned into MC / T-F / fill-in, swapped-term T/F traps). Answers go in folded callouts (`> [!success]- Answer`) citing the page. If the upcoming quiz is cumulative, add a `## Cumulative Review` block for earlier sources past quizzes drew from. Link the profile note with a wikilink.

Use Obsidian-style callouts (`> [!tip]`, `> [!example]`, `> [!warning]`) and tables throughout — they render natively in Obsidian and in most other markdown viewers, and they visually separate "core text" from "worked example" from "gotcha" at a glance. Do not add YAML frontmatter unless the user's existing notes already use it; when they do, mirror their keys (e.g. course, code, chapter, semester, tags) and set `type: summary` so course-index queries pick the note up.

## Filename & save location

- Name the file `Chapter N Summary - <Chapter Title>.md` (reuse the chapter title as stated in the textbook/slides).
- Save it inside the course's existing notes vault/folder, never overwriting an existing raw lecture-notes file for the same chapter — this note is a companion to those, not a replacement.
- If the destination folder is on the user's own computer (device bridge), write it there directly rather than only delivering it as a chat download, so it actually lands in their vault.

## Keeping format identical across courses

This skill is the single source of truth for the format — always re-derive the structure from this file, never from "how I did it last time" in conversation memory. Do not adapt the skeleton per-subject (finance vs. biology vs. history all get the same structure above); only the section *titles* inside part 6 change, to match that chapter's own subsection numbering.